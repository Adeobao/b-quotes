<html>
<head>
<meta "content-Type: text/html; charset=utf-8">
<meta name = 'viewport' content = 'width = device-width, intial-scale = 1.0, maximum-scale = 4.0, user-scalable = yes'>
<link rel = 'stylesheet' href = 'style.css' type = 'text/css'>
<title>Log Rankings: BQuotes - Anonymous Blogs & Quotes</title>

<link rel="stylesheet"
          href="https://fonts.googleapis.com/css?family=Montserrat">
    <style>
      body {
        font-family: 'Montserrat';
        font-size: 24px;
      }
    </style>
    
</head>
<body>
<?php
//error_reporting(0);



$db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8mb4', '2795841_adeoba', 'Makanjuola2');
$sql99 = $db->query('select id from posts order by rand() limit 1');
$row99 = $sql99->fetch(PDO::FETCH_ASSOC);
echo "<a href = 'random.php?page=".$row99['id']."'>Randomize</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href = 'index.php'>Home</a><hr>";
echo "Top 25 Posts by Net Votes";
echo "<hr>";
          
          $db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
          $sql2 = $db->query('select message, userid, ip, (love-diss) as aggr2 from posts order by (love-diss) desc limit 25');
          $row2 = $sql2->fetch(PDO::FETCH_ASSOC);
          
          
          echo "<ol>";

foreach($sql2 as $row2){
//show urls as links
$text = strip_tags($row2['message']);
$row2['message'] = preg_replace('@(https?://([-\w\.]+[-\w])+(:\d+)?(/([\w/_\.#-]*(\?\S+)?[^\.\s])?)?)@', '<a href="$1" target="_blank" rel="nofollow" style="background-color:wheat; color:blue;">$1</a>', $text);
//echo $row['message'];

echo "<li>", $row2['message'], ",", " with ", "<span class = 'blue'>", $row2['aggr2'], "</span>", "<span class = ''>", " Net,", " by ", $row2['ip'], "</span>", "<br><hr>", "</li>";
}
echo "</ol>";
 /*else {
        echo '<p>No results could be displayed.</p>';
        }
          while ($row2 = $sql2->fetch(PDO::FETCH_ASSOC)){
          echo "<ol>", "<li>", "<em>", "<span class = 'green'>", "Log:", "</span>", "&nbsp;&nbsp;&nbsp;&nbsp;", $row2['message'], ",", " with ", "<span class = 'blue'>", $row2['aggr2'], "</span>", "<span class = ''>", " Net,", " by ", $row2['ip'], "</span>", "</em><br><hr>", "</li>", "</ol>";         
          /*while ($row = $sql->fetch(PDO::FETCH_ASSOC)){
          echo "<em>", "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;", $row['message'], ",", " by ", $row['ip'], ", with ", "</span>", "<b>", "<span class = 'green'>", $row['max_love'], "</span>", "</b>", "<span class = ''>", " Likes", "</span>", "</em><br>";
          }*/
          //}
          echo "<hr>";
          

echo "<a href = 'random.php?page=".$row99['id']."'>Randomize</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href = 'index.php'>Home</a><hr>";

          ?>