<html>
    <head>
    <title>Post: BQuotes - Anonymous Blogs & Quotes</title>
    <meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=4.0, user-scalable=yes' />
    <link rel='stylesheet' type='text/css' href='style.css'>
    
    
    
    <meta name='description' content=''>
    <meta name='keywords' content='Posts, Text'>
    
    <link rel="stylesheet"
          href="https://fonts.googleapis.com/css?family=Montserrat">
    <style>
      body {
        font-family: 'Montserrat';
        font-size: 24px;
      }
    </style>

    </head>
    <!--<body class = 'default'>-->
    
        
      
            <br>
            <?php
            error_reporting(0);
$db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');			
              $sql = $db->query('SELECT id FROM posts ORDER BY rand() limit 1');
              $row = $sql->fetch(PDO::FETCH_ASSOC);
echo "<a href='random.php?page=".$row['id']."'>Randomize</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='index.php'>Home</a>";
//echo "<a href = 'auto-rand.php'>Auto-Randomize</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='index.php'>Home</a>";

echo '<hr>';
?>
    
         <script type = 'text/javascript'>
          var maxLength=140;
          function charLimit(el) {
              if (el.value.length > maxLength) return false;	
              return true;
          }
          function characterCount(el) {
              var charCount = document.getElementById('charCount');
              if (el.value.length > maxLength) el.value = el.value.substring(0,maxLength);
              if (charCount) charCount.innerHTML = maxLength - el.value.length;
              return true;
          }
      </script>
      <div data-role='main' class='ui-content'>
      
      
        <left>
          <?php    
          session_start();      
          echo "<br>";
              
              echo "Post Update:<br>";
              echo "<span class='mid_black'>Emojis: Use keypad's emojis</span><br>";
              echo "<span class='mid_black'>URLs: &nbsp;Use http://google.com for google.com</span><br>";
              ?>
            
         
          
    

      
      <?php
            
              echo '<form name="post-text" action="post-notif.php" method="post" data-ajax="false">                  
                      <textarea id = "url" rows="6" cols="18" wrap="hard" onKeyPress="return charLimit(this)" onKeyUp="return characterCount(this)" name="mymessage" wrap="physical"  style="border-radius:5px; padding: 4px 14px;"></textarea><br />
                      
                      
                      <p><strong><span id="charCount">140</span></strong> characters remaining.</p>
                      Enter Image Text:<img src="captcha.php" /><br />
                      <input name="captcha" type="number"  style="border-radius:5px; padding: 4px 14px;"><br>
                      <!--<label><em>Username:</em></label><br>
                      <input type = "text" name = "username"><br>
                      <label><em>Password:</em></label><br>
                      <input type = "password" name = "password" /><br>-->
                      <input type="submit" value="Post"  style="border-radius:5px; padding: 4px 14px;"><br />
                    </form>';
                    
                    echo '</p></div></div>';

//echo "<em>Not yet registered? You need to <a href = 'register.php'>register</a> to post. Reset your password <a href = 'reset-pass.php'>Here</a>.</em>";
?>


                                
          <hr/>
          <?php
/*$db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');			
              $sql = $db->query('SELECT id FROM posts ORDER BY rand() limit 1');
              $row = $sql->fetch(PDO::FETCH_ASSOC);*/
echo "<a href='random.php?page=".$row['id']."'>Randomize</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='index.php'>Home</a>";
//echo "<a href = 'auto-rand.php'>Auto-Randomize</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='index.php'>Home</a>";
?>
          <br>
<center><footer>
       <?php include("counter.php");?>     

     </footer></center>

    
    </body>
    </html>