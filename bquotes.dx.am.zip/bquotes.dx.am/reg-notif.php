<html>
<head>
<title>Registration Notification: BQuotes</title>
<meta name = 'viewport' content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no'>
<link rel = 'stylesheet' href = 'style.css' type = 'text/css'>
</head>
<?php
error_reporting(0);
session_start();
$db = new PDO ('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
$sql = $db->query('select id from posts order by rand() limit 1');
$row = $sql->fetch(PDO::FETCH_ASSOC);
echo "<a href = 'random.php?page=".$row['id']."'>Randomize</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href = 'index.php'>Home</a>";
echo "<hr>";
$username = $_POST['username'];
$email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
//$password = crypt($_POST['password'], '$2aS$07$'.microtime());
//$user_check = rand(123456789, 987654321);
$user_hash = md5(uniqid(rand(), TRUE));
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
$db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');

$sql = $db->prepare('select email from users where email = :email');
$sql->bindParam(':email', $email);
$row = $sql->execute();
$sql->setFetchMode(PDO::FETCH_ASSOC);
$row = $sql->fetch();

if (!empty($username)&&($email)&&($password)&&!empty($_POST['captcha'])&&($_POST['captcha'] == $_SESSION['code'])){
$sql = $db->prepare("INSERT into users (username, email, password) values (:username, :email, :password)");
//$sql->bindParam(':id', $id);
$sql->bindParam(':username', $username);
$sql->bindParam(':email', $email);
$sql->bindParam(':password', $password);
//$sql->bindParam(':user_hash', $user_hash);
$row = $sql->execute();
//echo $row;
echo '<span class = "green"><em>Registration successful. You may <a href = "post.php">Post</a> now.</em></span>';
}
else {echo '<span class = "red"><em>Registration unsuccessful. You have one or more invalid fields.</em></span>';}
echo "<hr>";
$db = new PDO ('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
$sql = $db->query('select id from posts order by rand() limit 1');
$row = $sql->fetch(PDO::FETCH_ASSOC);
echo "<a href = 'random.php?page=".$row['id']."'>Randomize</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href = 'index.php'>Home</a>";

?>
