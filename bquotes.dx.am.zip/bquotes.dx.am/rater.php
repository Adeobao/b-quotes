<?php
//rater

             //Weighted random select
              /*$db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
              $sqlrr = $db->query('SELECT id FROM posts ORDER BY -LOG(1.0 - RAND()) / weight LIMIT 1');
              $rowrr = $sqlrr->fetch(PDO::FETCH_ASSOC);
              $pid = $rowrr['id'];*/
              
              
                           
              $pid = $_GET['page'];
              $like = $_POST['like'];
              $diss = $_POST['diss'];
              $db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');			
              if (isset($like)){
              $sql = $db->query('update posts set love = love + 1 where id =' .$pid);
              }
              elseif (isset($diss)){
              $sql = $db->query('update posts set diss = diss + 1 where id =' .$pid);
              }
              
              
              echo "<form name = 'rater' action = '' method = 'post'>";
              echo "<input type = 'submit' name = 'like' value = 'like' style='border-radius:5px; padding: 4px 14px;'>";
              
              $db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
              $pid = $_GET['page'];
              $sql0 = $db->query('select love from posts where id=' .$pid);
              execute;
              $row0 = $sql0->fetch(PDO::FETCH_ASSOC);
              echo "<span class = 'green'>", $row0['love'], "</span>";
              
              echo "&nbsp;&nbsp;&nbsp;", "<input type = 'submit' name = 'diss' value = 'diss' style='border-radius:5px; padding: 4px 14px;'>";
              
              $db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
              $pid = $_GET['page'];
              $sql = $db->query('select diss from posts where id=' .$pid);
              $row = $sql->fetch(PDO::FETCH_ASSOC);
              echo "<span class = 'red'>", $row['diss'], "</span>", "&nbsp;&nbsp;Net Rating: <span class = 'blue'>", $row0['love']-$row['diss'], "</span>";
              echo "</form>";
                  
                  
          echo "</div>";
          ?>