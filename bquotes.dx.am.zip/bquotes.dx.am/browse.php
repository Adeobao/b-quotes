<html>
    <head>
    <title>Browse: BQuotes</title>
    <meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no' />
    <link rel='stylesheet' type='text/css' href='style.css'>
    <meta name='description' content=''>
    <meta name='keywords' content='Blogs, Quotes, Music'>
    </head>
    <body class = 'default'>
<!--uppermost links-->
<a href='post.php'>Log</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='index.php'>Home</a><hr>


            <?php
            error_reporting(0);
            //upper pagination 
            //error_reporting(E_ALL); ini_set('display_errors', 1);
              session_start();                     
              $db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
              
    // Find out how many items are in the table
    $db = new PDO('mysql:host=fdb13.awardspace.net;dbname=2107121_defa;charset=utf8', '2107121_defa', 'Makanjuola2');
    $total = $db->query('
        SELECT
            *
        FROM
            posts
    ')->rowCount();

    // How many items to list per page
    $limit = 1;

    // How many pages will there be
    $pages = ceil($total / $limit);

    // What page are we currently on?
    $page = min($pages, filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT, array(
        'options' => array(
            'default'   => 1,
            'min_range' => 1,
        ),
    )));

    // Calculate the offset for the query
    $offset = ($page - 1)  * $limit;

    // Some information to display to the user
    $start = $offset + 1;
    $end = min(($offset + $limit), $total);

    // The "back" links
    $prevlink = ($page > 1) ? '<a href="browse.php?page=1" title="First page"><em>First</em>&nbsp;&nbsp;&nbsp;</a> <a href="?page=' . ($page - 1) . '" title="Previous page"><em>Previous</em></a>' : '<span class="disabled"><em>First</em>&nbsp;&nbsp;&nbsp;</span> <span class="disabled"><em>Previous</em></span>';

    // The "forward" links
    $nextlink = ($page < $pages) ? '<a href="browse.php?page=' . ($page + 1) . '" title="Next page"><em>Next</em>&nbsp;&nbsp;&nbsp;</a> <a href="?page=' . $pages . '" title="Last page"><em>Last</em></a>' : '<span class="disabled"><em>Next</em>&nbsp;&nbsp;&nbsp;</span> <span class="disabled"><em>Last</em></span>';

    // Display the paging information
    echo '<div id="paging"><p>', $prevlink, '<em>', ' Page ', $page, ' of ', $pages, ' pages, displaying ', $start, '-', $end, ' of ', $total, ' results ', '</em>', $nextlink, ' &nbsp;&nbsp;&nbsp;';

 
 $db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');			
              $sqlr = $db->query('SELECT id FROM posts ORDER BY RAND() LIMIT 4');
              $rowr = $sqlr->fetch(PDO::FETCH_ASSOC);
echo "<a href='random.php?page=".$rowr['id']."'><i>Randomize.</i></a><br><br>";

//$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//prepare paged query
$stmt = $db->prepare('select * from posts order by id asc limit :limit offset :offset');

// Bind the query params    
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();

    // Do we have any results?
    if ($stmt->rowCount() > 0) {
        // Define how we want to fetch the results
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $iterator = new IteratorIterator($stmt);



foreach($iterator as $row){
              echo "Log: ", "<em>", ($row['message']), "</em>", "&nbsp;&nbsp;<a href = 'edit.php?page=".$row['id']."&username=".$row['username']."'><span class = 'small_blue'><em>Edit</em></span></a>", "<br>";
              echo "By: ", "&nbsp;&nbsp;", "<span class = ''>", "<em>", $row['username'], "</em>", "</span>", "<br>";
              echo "On: ", "</em>", "&nbsp;&nbsp;", "<em>", ($row['date']), "</em>", "<br>";

              $pid = $_GET['page'];
              $like = $_POST['like'];
              $diss = $_POST['diss'];
              $db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');			
              if (isset($like)){
              $sql = $db->query('update posts set love = love + 1 where id =' .$pid);
              }
              elseif (isset($diss)){
              $sql = $db->query('update posts set diss = diss + 1 where id =' .$pid);
              }
              
              echo "<form name = 'rater' action = '' method = 'post'>";
              echo "<input type = 'submit' name = 'like' value = 'like' />";
              
              $db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
              $pid = $_GET['page'];
              $sql0 = $db->query('select love from posts where id=' .$pid);
              $row0 = $sql0->fetch(PDO::FETCH_ASSOC);
              echo "<span class = 'blue'><em>", $row0['love'], "</em></span>";
              
              echo "&nbsp;&nbsp;&nbsp;", "<input type = 'submit' name = 'diss' value = 'diss' />";
              
              $db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
              $pid = $_GET['page'];
              $sql = $db->query('select diss from posts where id=' .$pid);
              $row = $sql->fetch(PDO::FETCH_ASSOC);
              echo "<span class = 'red'><em>", $row['diss'], "</em></span>";
              $aggr = $row0['love'] - $row['diss'];
              echo "&nbsp;&nbsp;<em>Aggregate Rating:</em> ", "<span class = 'blue'><em>", $aggr, "</em></span>";
              echo "</form>";

            }

} else {
        echo '<p>No results could be displayed.</p>';
        }
              echo "&nbsp;&nbsp;&nbsp;";
              
              
echo "</div>";
          
          $sql = $db->query('SELECT COUNT(id) FROM posts');
          $row = $sql->fetch(PDO::FETCH_ASSOC);
          echo "<em>", ($row['COUNT(id)']), "</em>", " <em>Entries in Database</em>";
          
          echo "<br>";
          
          //lower pagination 
            //error_reporting(E_ALL); ini_set('display_errors', 1);
              session_start();                     
              $db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
              
              // The "back" links
              $prevlink = ($page > 1) ? '<a href="browse.php?page=1" title="First page"><em>First</em>&nbsp;&nbsp;&nbsp;</a> <a href="?page=' . ($page - 1) . '" title="Previous page"><em>Previous</em></a>' : '<span class="disabled"><em>First</em>&nbsp;&nbsp;&nbsp;</span> <span class="disabled"><em>Previous</em></span>';

              // The "forward" links
              $nextlink = ($page < $pages) ? '<a href="browse.php?page=' . ($page + 1) . '" title="Next page"><em>Next</em>&nbsp;&nbsp;&nbsp;</a> <a href="?page=' . $pages . '" title="Last page"><em>Last</em></a>' : '<span class="disabled"><em>Next</em>&nbsp;&nbsp;&nbsp;</span> <span class="disabled"><em>Last</em></span>';

              // Display the paging information
              echo '<div id="paging"><p>', $prevlink, '<em>', ' Page ', $page, ' of ', $pages, ' pages, displaying ', $start, '-', $end, ' of ', $total, ' results ', '</em>', $nextlink, ' &nbsp;&nbsp;&nbsp;';

              echo "<a href='random.php?page=".$rowr['id']."'><i>Randomize.</i></a><br>";
              
              echo "&nbsp;&nbsp;&nbsp;";
              
              $browse = $page*1;
              $tbl='posts';
              $id=$_GET['page'];

          echo "<hr>";
          
          $db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
          $sql2 = $db->query('select message, username, max(love-diss) as aggr2 from posts group by (love-diss) desc limit 1');
          $row2 = $sql2->fetch(PDO::FETCH_ASSOC);
          echo "<em>", "<span class = ''>", "Current Best Log is:", " ", $row2['message'], ",", " by ", $row2['username'], ", with ", "</span>", "<span class = 'blue'>", $row2['aggr2'], "</span>", "<span class = ''>", " Aggregate", "</span>", "</em><br>";         
          /*while ($row = $sql->fetch(PDO::FETCH_ASSOC)){
          echo "<em>", "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;", $row['message'], ",", " by ", $row['ip'], ", with ", "</span>", "<b>", "<span class = 'green'>", $row['max_love'], "</span>", "</b>", "<span class = ''>", " Likes", "</span>", "</em><br>";
          }*/
          
          $sql3 = $db->query('select message, username, max(diss-love) as aggr3 from posts group by (diss-love) desc limit 1');
          $row3 = $sql3->fetch(PDO::FETCH_ASSOC);
          echo "<em>", "<span class = ''>", "Current Worst Log is:", " ", $row3['message'], ",", " by ", $row3['username'], ", with ", "</span>", "<span class = 'red'>", "-", $row3['aggr3'], "</span>", "<span class = ''>", " Aggregate", "</span>", "</em><br>";         
          /*while ($row = $sql->fetch(PDO::FETCH_ASSOC)){
          echo "<em>", "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;", $row['message'], ",", " by ", $row['ip'], ", with ", "</span>", "<b>", "<span class = 'red'>", $row['max_diss'], "</span>", "</b>", "<span class = ''>", " Disses", "</span>", "</em><br>";
          }*/
          
          echo "<hr>";
          
          echo "<form name = 'search' action = 'search-notif.php' method = 'get'>
          <input type ='hidden' name = 'page' value = '1'>
          <label><em>Search entries by Log, Username or Date: (You can use this to find your posts for editing.)</em></label><br>
          <input type = 'text' name = 'term'><br>
          <input type = 'submit' name = 'search' value = 'Search'>
          <hr>"

        ?>        
        
      <!--lower links-->
      <a href="post.php">Log</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='index.php'>Home</a>
      
          

         
      </body>
</html>