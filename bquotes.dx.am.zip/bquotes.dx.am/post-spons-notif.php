<html>
    <head>
    <title>Sponsor Update Notification: BQuotes - Anonymous Blogs & Quotes</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=4.0, user-scalable=yes" />
    <link rel="stylesheet" type="text/css" href="style.css">

   <link rel="stylesheet"
          href="https://fonts.googleapis.com/css?family=Montserrat">
    <style>
      body {
        font-family: 'Montserrat';
        font-size: 24px;
      }
    </style>

   </head>
    <!--<body class = 'default'>-->
      
            <br>
            <?php
    error_reporting(0);


$db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');			
session_start();
//error_reporting(E_ALL);
//Define variables
    $tbl_name="posts"; // Table name 
    $string = ($_POST['mymessage']);
             
		if (!empty($_SERVER["HTTP_CLIENT_IP"]))
{
 //check for ip from share internet
 $ip = $_SERVER["HTTP_CLIENT_IP"];
}
elseif (!empty($_SERVER["HTTP_X_FORWARDED_FOR"]))
{
 // Check for the Proxy User
 $ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
}
else
{
 $ip = $_SERVER["REMOTE_ADDR"];
}

// This will print user's real IP Address
// does't matter if user using proxy or not.
//echo "<span class = 'small_blue'>", $ip, "</span>", ", ";

                      
$string = $_POST['message'];
$password = $_POST['password'];
$userid = $_POST['userid'];
$db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');			

$stmt = $db->query("select SUM(weight) AS totweight from posts");
$stmt->execute();
$sum = $stmt->fetch();
//echo $sum['totweight'];
/*if ($_POST['visibility'] > 45){
exit ("Your Visibility level should be between 1 and 45");
}*/

$visibility = $_POST['visibility'];

$real_vi = ($visibility/$sum['totweight'])*100;

//dynamically make visibility 35% (see post-spons.php)
//$vi_dyn = (35*$sum['totweight'])/100

//echo $real_vi;

$db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
$stmt2=$db->prepare("select password from users where userid = :userid");
$stmt2->bindParam(':userid', $userid);
$stmt2->execute();
$pass= $stmt2->fetchColumn();
//$pass = $result['password'];

//echo $password;
//$input_password = password_verify($_POST['password'], $password);

		/*if ((strcmp($username, $row['username'])==0)&&($input_password)&&(!empty($message))
&&(isset($_POST["captcha"])&&$_POST["captcha"]!=""&&$_SESSION["code"]==$_POST["captcha"]
)&&(isset($_POST['username'])))*/if (isset($string)&&isset($_POST['captcha'])&&($_SESSION['code']==$_POST['captcha'])) {
			//Make links clickable
                        
//Use this (works with ftp, http, ftps and https schemes):

function make_links_clickable($string){
    return preg_replace('!(((f|ht)tp(s)?://)[-a-zA-Zа-яА-Я()0-9@:%_+.~#?&;//=]+)!i', '<a href="$1">$1</a>', $string);
}
                        
                        // Insert data into mysql
                        $db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
			//$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                        $sql = $db->prepare('INSERT INTO posts (message, weight, ip, date, love, diss)VALUES(:message, :weight, :ip, CURDATE(), "0", "0")');
			$sql->bindParam(':message', $string);
                        $sql->bindParam(':weight', $visibility);
			$sql->bindParam(':ip', $ip);
                        $row2 = $sql->execute();
                        }
                        
                        $sqlv = $db->query('SELECT * from posts ORDER BY id DESC LIMIT 1');
                        $view = $sqlv->fetch();
                        
                    if ($row2){echo "<span class = 'green'><em>", $ip, ", ", "Your Sponsored Update was Successful. View it <a href='random.php?page=".$view['id']."'>Here</a>. It will appear ", $real_vi, "% ", "of the time.</em></span>";
	                }

		else {
		echo "<span class = 'red'><em>Your Sponsored Update was not Successful. You have one or more invalid fields.</em></span>";
		}
	
	                       
        ?>
      


          
          <br/> 
          <hr/>
          <?php
$db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');			
              $sql99 = $db->query('SELECT id FROM posts ORDER BY rand () limit 1');
              $row99 = $sql99->fetch(PDO::FETCH_ASSOC);
echo "<a href='random.php?page=".$row99['id']."'>Randomize</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='post.php'>Log</a>";
//echo "<a href = 'auto-rand.php'><em>Auto-Randomize</em></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='post.php'><em>Log</em></a>";
?>
          <br/>

    
    </body>
    </html>
          
