<html>
<head>
<title>Edit Notification: BQuotes</title>
<meta name = 'viewport' content = 'width = device-width, initial-scale = 1.0, maximum-scale = 1.0, user-scalable = no'>
<link rel = 'stylesheet' href = 'style.css' type = 'text/css'>
</head>
<?php
error_reporting(0);
session_start();
$id = $_POST['id'];
$username = $_POST['username'];
$message = $_POST['message'];
$input_password = $_POST['password'];
$db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
$sql0 = $db->query('select id from posts order by rand() limit 1');
$row0 = $sql0->fetch(PDO::FETCH_ASSOC);
echo "<a href = 'random.php?page=".$row0['id']."'>Randomize</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href = 'index.php'>Home</a>";
echo "<hr>";
$sql = $db->prepare('select password from users where username = :username');
$sql->bindParam(':username', $username);
$sql->execute();
$sql->setFetchMode(PDO::FETCH_ASSOC);
$row = $sql->fetch();
$password = $row['password'];
if (password_verify($input_password, $password)&&(!empty($_POST['captcha']))&&($_POST['captcha'] == $_SESSION['code'])){
$sql2 = $db->prepare('update posts set message = :message where id = :id');
$sql2->bindParam(':message', $message);
$sql2->bindParam(':id', $id);
$row2 = $sql2->execute();
if ($row2){echo "<span class = 'green'><em>Edit successful.</em></span>";} 
}else {echo "<span class = 'red'><em>Edit unsuccessful. You have one or more invalid fields.</em></span>";}
echo "<hr>";
echo "<a href = 'random.php?page=".$row0['id']."'>Randomize</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href = 'index.php'>Home</a>";
?>