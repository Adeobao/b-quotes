<html>
    <head>
    <title>BQuotes - Anonymous Blogs & Quotes - Random</title>
    <meta charset="UTF-8">
    <meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=4.0, user-scalable=yes' />
    <link rel='stylesheet' type='text/css' href='style.css'>
    <meta name='description' content=''>
    <meta name='keywords' content='Blogs, Quotes, Music'>
    <script type="text/javascript" src="https://platform-api.sharethis.com/js/sharethis.js#property=5ebae8e408cfa2001202b260&product=inline-share-buttons" async="async"></script>
    
    <link rel="stylesheet"
          href="https://fonts.googleapis.com/css?family=Montserrat">
    <style>
      body {
        font-family: 'Montserrat';
        font-size: 24px;
      }
    </style>

    </head>
    <!--<body class = 'default'>-->

<?php
$db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
$sql99 = $db->query('select id from posts order by id desc limit 1');
$row99 = $sql99->fetch(PDO::FETCH_ASSOC);
echo "<a href='post.php'>Post</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='index.php'>Home</a><hr>";

            error_reporting(0);
            //error_reporting(E_ALL);
              session_start();                     
              
              //delete old sponsored posts
              $sqlold = $db->exec("DELETE FROM posts WHERE weight > 1 AND date < CURDATE() - INTERVAL 7 DAY");
              
              
              //Weighted random select
              $sqlrr = $db->query('SELECT id FROM posts ORDER BY -LOG(1.0 - RAND()) / weight LIMIT 1');
              $rowrr = $sqlrr->fetch(PDO::FETCH_ASSOC);
              echo "<a href='random.php?page=".$rowrr['id']."'>Re - Randomize</a>&nbsp;&nbsp;&nbsp;&nbsp;<p>";
              echo "<hr>";
              
          $tbl='posts';
          $id=$_GET['page'];
          
          $sql = $db->query("SELECT * from $tbl WHERE id = ".$_GET['page']." ") or die ('Nothing to Show Now!');
          $row = $sql->fetch(PDO::FETCH_ASSOC);
              
              if ($row){
              
 
              $text = strip_tags($row['message']);
$row['message'] = preg_replace('@(https?://([-\w\.]+[-\w])+(:\d+)?(/([\w/_\.#-]*(\?\S+)?[^\.\s])?)?)@', '<a href="$1" target="_blank" rel="nofollow" style="background-color: wheat; color: blue">$1</a>', $text);
//echo $textWithLinks;

              
              if ($row['weight'] > 1){
              
              echo ($row['message']), "&nbsp;&nbsp;<span class='small_blue'><b><sup>sponsored</sup></b></span>", "&nbsp;&nbsp;<a href = 'report.php?page=".$row['id']."&ip=".$row['ip']."' style='background-color: wheat;'><span class = 'small_red'><b><sup>report</sup></b></span></a>", "<br>"; 
              echo "ID: ", "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;", ($row['id']), "<br>";
              echo "IP: ", "&nbsp;&nbsp;&nbsp;&nbsp;", "<span class = ''>", $row['ip'], "</span>", "<br>";
              echo "Date: ", " ", ($row['date']), "<br>";
              echo "Views: ", $row['views'], "<br>";
              }
              else
              {
              
              echo ($row['message']), "&nbsp;&nbsp;<a href = 'report.php?page=".$row['id']."&ip=".$row['ip']."' style='background-color: wheat;'><span class = 'small_red'><b><sup>report</sup></b></span></a>", "<br>"; 
              echo "ID: ", "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;", ($row['id']), "<br>";
              echo "IP: ", "&nbsp;&nbsp;&nbsp;&nbsp;", "<span class = ''>", $row['ip'], "</span>", "<br>";
              echo "Date: ", " ", ($row['date']), "<br>";
              echo "Views: ", $row['views'], "<br>";
              }
              
               echo '<div class="sharethis-inline-share-buttons"></div><br>';  
               
               //increment view count
               $sqlview = $db->exec("update posts SET views = views + 1 WHERE id = ".$_GET['page']." ");
               
              //echo '<div class="sharethis-inline-reaction-buttons"></div><br>';
              
              //old rater
             $pid = $_GET['page'];
              $like = $_POST['like'];
              $diss = $_POST['diss'];
              $db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');			
              if (isset($like)){
              $sql = $db->query('update posts set love = love + 1 where id =' .$pid);
              }
              elseif (isset($diss)){
              $sql = $db->query('update posts set diss = diss + 1 where id =' .$pid);
              }
              
              echo "<iframe src='rater.php?page=".$row['id']."' title='rater'></iframe>";
              
              /*echo "<form name = 'rater' action = '' method = 'post'>";
              echo "<input type = 'submit' name = 'like' value = 'like' style='border-radius:5px; padding: 4px 14px;'>";
              
              $db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
              $pid = $_GET['page'];
              $sql0 = $db->query('select love from posts where id=' .$pid);
              $row0 = $sql0->fetch(PDO::FETCH_ASSOC);
              echo "<span class = 'green'>", $row0['love'], "</span>";
              
              echo "&nbsp;&nbsp;&nbsp;", "<input type = 'submit' name = 'diss' value = 'diss' style='border-radius:5px; padding: 4px 14px;'>";
              
              $db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
              $pid = $_GET['page'];
              $sql = $db->query('select diss from posts where id=' .$pid);
              $row = $sql->fetch(PDO::FETCH_ASSOC);
              echo "<span class = 'red'>", $row['diss'], "</span>", "&nbsp;&nbsp;Net Rating: <span class = 'blue'>", $row0['love']-$row['diss'], "</span>";
              echo "</form>";
                  */
                  }
                  else echo "Nothing to show here!</p>";
          echo "</div>";
          
          
          $sql = $db->query("SELECT COUNT(id) FROM posts");
          $row = $sql->fetch(PDO::FETCH_ASSOC);
           echo ($row['COUNT(id)']), " Entries in Database", "<p>";
           echo "<a href = 'https://flutterwave.com/pay/nwr4audsd59d'>Place An Ad</a>";
           echo "<hr>";
          
          $db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
              
              echo "<a href='random.php?page=".$rowrr['id']."'>Re - Randomize</a>&nbsp;&nbsp;&nbsp;&nbsp;";

          echo "<hr>";
          
          $db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
          $sql2 = $db->query('select message, userid, ip, max(love-diss) as aggr2 from posts group by (love-diss) desc limit 1');
          $row2 = $sql2->fetch(PDO::FETCH_ASSOC);
          
          //convert urls to links
          $text = strip_tags($row2['message']);
$row2['message'] = preg_replace('@(https?://([-\w\.]+[-\w])+(:\d+)?(/([\w/_\.#-]*(\?\S+)?[^\.\s])?)?)@', '<a href="$1" target="_blank" rel="nofollow" style="background-color: wheat; color: blue">$1</a>', $text);

          //echo "<span class = 'green'>", "Current Best Log is:", "</span>", "&nbsp;&nbsp;&nbsp;&nbsp;", $row2['message'], ",", " with ", "<span class = 'blue'>", $row2['aggr2'], "</span>", "<span class = ''>", " Net,", " by ", $row2['ip'], "</span>", "<br>";         
          
          //echo "<hr>";
          $sql3 = $db->query('select message, userid, ip, max(diss-love) as aggr3 from posts group by (diss-love) desc limit 1');
          $row3 = $sql3->fetch(PDO::FETCH_ASSOC);
          
          $text = strip_tags($row2['message']);
$row2['message'] = preg_replace('@(https?://([-\w\.]+[-\w])+(:\d+)?(/([\w/_\.#-]*(\?\S+)?[^\.\s])?)?)@', '<a href="$1" target="_blank" rel="nofollow" style="background-color: wheat; color: blue">$1</a>', $text);

          //echo "<span class = 'red'>", "Current Worst Log is:", "</span>", " ", $row3['message'], ",", " with ", "<span class = 'blue'>", "-", $row3['aggr3'], "</span>", "<span class = ''>", " Net,", " by ", $row3['ip'], "</span>", "<br>";         
          
          //echo "<hr>";
          echo "<center><a href='rankings.php'>View full rankings</a></center><hr>";
          
          echo "<form name = 'search' action = 'search-notif.php' method = 'get'>
          <input type ='hidden' name = 'page' value = '1'>
          <label>Search entries by ID, Update, IP or Date; or leave blank to search all entries:</label><br>
          <input type = 'text' name = 'term' style='border-radius:5px; padding: 4px 14px;'><br>
          <input type = 'submit' name = 'search' value = 'Search'  style='border-radius:5px; padding: 4px 14px;'>";
          
          echo "<hr>";
          
          echo "<a href='post.php'>Post</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='index.php'>Home</a>";
          ?>
          <br>
          <center><footer>
       <?php include("counter.php");?>     

     </footer></center>


      </body>
</html>