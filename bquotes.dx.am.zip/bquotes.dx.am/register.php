<html>
    <head>
    <title>Register: BQuotes</title>
    <meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no' />
    <link rel='stylesheet' type='text/css' href='style.css'>
    <meta name='description' content=''>
    <meta name='keywords' content='Blogs, Quotes, Music'>
    </head>
    <body class = 'default'>
<!--uppermost links-->
<?php
$db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
$sql = $db->query('select id from posts order by rand() limit 1');
$row = $sql->fetch(PDO::FETCH_ASSOC);
echo "<a href = 'random.php?page=".$row['id']."'>Randomize</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='index.php'>Home</a>";

echo "<hr>
<form name = 'register' action = 'reg-notif.php' method = 'post'>
<label><em>Register for BQuotes</em></label><br>
<label>------</label><br>
<label><em>All fields are mandatory.</em></label><br><br>
<!--<label>------</label><br>-->
<label><em>Username:</em></label><br>
<input type = 'text' name = 'username'><br>
<label><em>Email:</em></label><br>
<input type = 'text' name = 'email'><br>
<label><em>Password:</em></label><br>
<input type = 'password' name = 'password'><br>
<em>Enter Image Text:</em><img src='captcha.php' /><br />
<input name='captcha' type='text' /><br>
<input type = 'submit' name = 'submit' value = 'Register!'><p>
<em>Reset your password <a href = 'reset-pass.php'>Here</a></em><br>
<hr>
<a href = 'random.php?page=".$row['id']."'>Randomize</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='index.php'>Home</a>";
?>

</body>
</html>