<html>
<head>
<title>Report Log Notification: BQuotes - Anonymous Blogs & Quotes</title>
<meta name = 'viewport' content = 'width = device-width, initial-scale = 1.0, maximum-scale = 4.0, user-scalable = yes'>
<link rel = 'stylesheet' href = 'style.css' type = 'text/css'>

<link rel="stylesheet"
          href="https://fonts.googleapis.com/css?family=Montserrat">
    <style>
      body {
        font-family: 'Montserrat';
        font-size: 24px;
      }
    </style>

</head>
<!--<body class = 'default'>-->

<?php
error_reporting(0);
session_start();
$id = $_POST['id'];
$ip = $_POST['ip'];
$message = $_POST['message'];
$comments = $_POST['comments'];

$myemail = "adeobao@bquotes.dx.am";
$headers = "From:BQuotes - Report Log <$myemail>\r\n";
$headers .= "Reply-To: $name <$email>\r\n";

$msg = 'Dear Adeoba, a log ' . $message . ' on BQuotes with ID: ' . $id . ', from ' . $ip . ' has been reported as inappropriate, with comments ' . $comments . ' Please take action.';
//echo $_SESSION['code'];
//echo $_POST['captcha'];

if (isset($_POST['captcha'])&&($_SESSION['code']==$_POST['captcha'])){
mail ($myemail, 'BQuotes - Report Log', $msg, $headers);
echo "<span class = 'green'><em>Report successful.</em></span>";
}
else {
echo "<span class = 'red'><em>Report unsuccessful. You have one or more invalid fields.</em></span>";
}

echo "<hr>";
$db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
$sql0 = $db->query('select id from posts order by rand() limit 1');
$row0 = $sql0->fetch(PDO::FETCH_ASSOC);

echo "<a href = 'random.php?page=".$row0['id']."'>Randomize</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href = 'index.php'>Home</a>";
?>

</body>
</html>