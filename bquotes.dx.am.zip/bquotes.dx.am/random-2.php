<?php session_start(); ?>
<html>
    <head>
    <title>Random: BQuotes - Anonymous Blogs & Quotes</title>
    <meta charset="UTF-8">
    <meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no' />
    <link rel='stylesheet' type='text/css' href='style.css'>
    <meta name='description' content=''>
    <meta name='keywords' content='Blogs, Quotes, Music'>
    <script type="text/javascript" src="https://platform-api.sharethis.com/js/sharethis.js#property=5ebae8e408cfa2001202b260&product=inline-share-buttons" async="async"></script>
    </head>
    <body class = 'default'>

<?php>

$db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
$sql99 = $db->query('select id from posts order by id desc limit 1');
$row99 = $sql99->fetch(PDO::FETCH_ASSOC);
echo "<a href='post.php'>Log</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='index.php'>Home</a><hr>";

            error_reporting(0);
            //error_reporting(E_ALL);
              session_start();                     
              
              //Random select by weight
              $sqlrr = $db->query('SELECT id FROM posts ORDER BY -LOG(RAND())/weight LIMIT 1');
              $rowrr = $sqlrr->fetch(PDO::FETCH_ASSOC);
              echo "<a href='random-2.php?page=".$rowrr['id']."'><em>Re - Randomize.</em></a>&nbsp;&nbsp;&nbsp;&nbsp;<p>";
              echo "<hr>";
              
          $tbl='posts';
          $id=$_GET['page'];
          
          $sql = $db->query("SELECT * from $tbl WHERE id = ".$_GET['page']." ") or die ('Nothing to Show Now!');
          $row = $sql->fetch(PDO::FETCH_ASSOC);
              
              if ($row){
              
 
              $text = strip_tags($row['message']);
$row['message'] = preg_replace('@(https?://([-\w\.]+[-\w])+(:\d+)?(/([\w/_\.#-]*(\?\S+)?[^\.\s])?)?)@', '<a href="$1" target="_blank" rel="nofollow">$1</a>', $text);
//echo $textWithLinks;
              //if ($row['sort'] == "text"){
              echo "<span class='blue'><em>ID</em></span>: ", "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;", "<em>", ($row['id']), "</em>", "<br>";
              echo "<span class='blue'><em>Log</em></span>: ", "&nbsp;&nbsp;", "<em>", ($row['message']), "</em>", "&nbsp;&nbsp;<a href = 'report.php?page=".$row['id']."&ip=".$row['ip']."'><span class = 'small_red'><em><b><sup>report</sup></b></em></span></a>", "<br>"; 
              echo "<span class='blue'><em>IP</em></span>: ", "&nbsp;&nbsp;&nbsp;&nbsp;", "<span class = ''>", "<em>", $row['ip'], "</em>", "</span>", "<br>";
              echo "<span class='blue'><em>Date</em></span>: ", " ", "<em>", ($row['date']), "</em>", "<br>";
              //}
              
               echo '<div class="sharethis-inline-share-buttons"></div><br>';                
             
             if (!empty($_SERVER["HTTP_CLIENT_IP"]))
{
 //check for ip from share internet
 $ip = $_SERVER["HTTP_CLIENT_IP"];
}
elseif (!empty($_SERVER["HTTP_X_FORWARDED_FOR"]))
{
 // Check for the Proxy User
 $ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
}
else
{
 $ip = $_SERVER["REMOTE_ADDR"];
}


             $pid = $_GET['page'];
              $like = $_POST['like'];
              $diss = $_POST['diss'];
              $db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');			
              if (isset($like)&&!isset($_SESSION['like'])){
              $sql = $db->query('update posts set love = love + 1 where id =' .$pid);
              }
              elseif (isset($diss)&&!isset($_SESSION['diss'])){
              $sql = $db->query('update posts set diss = diss + 1 where id =' .$pid);
              }
              else {echo "You have already voted. Try again later.";}
              
              echo "<form name = 'rater' action = '' method = 'post'>";
              echo "<input type = 'submit' name = 'like' value = 'like' />";
              
              $db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
              $pid = $_GET['page'];
              $sql0 = $db->query('select love from posts where id=' .$pid);
              $row0 = $sql0->fetch(PDO::FETCH_ASSOC);
              echo "<span class = 'green'><em>", $row0['love'], "</em></span>";
              
              echo "&nbsp;&nbsp;&nbsp;", "<input type = 'submit' name = 'diss' value = 'diss' />";
              
              $db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
              $pid = $_GET['page'];
              $sql = $db->query('select diss from posts where id=' .$pid);
              $row = $sql->fetch(PDO::FETCH_ASSOC);
              echo "<span class = 'red'><em>", $row['diss'], "</em></span>", "&nbsp;&nbsp;<em>Net Rating: <span class = 'blue'>", $row0['love']-$row['diss'], "</span></em>";
              echo "</form>";
                  
                  }
                  else echo "<em>Nothing to show!</em></p>";
          echo "</div>";
          
          $sql = $db->query("SELECT COUNT(id) FROM posts");
          $row = $sql->fetch(PDO::FETCH_ASSOC);
           echo "<em>", ($row['COUNT(id)']), " Entries in Database</em>", "<p>";
           echo "<hr>";
          
          $db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
              
              echo "<a href='random.php?page=".$rowrr['id']."'><em>Re - Randomize.</em></a>&nbsp;&nbsp;&nbsp;&nbsp;";

          echo "<hr>";
          
          $db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
          $sql2 = $db->query('select message, username, ip, max(love-diss) as aggr2 from posts group by (love-diss) desc limit 1');
          $row2 = $sql2->fetch(PDO::FETCH_ASSOC);
          
          //convert urls to links
          $text = strip_tags($row2['message']);
$row2['message'] = preg_replace('@(https?://([-\w\.]+[-\w])+(:\d+)?(/([\w/_\.#-]*(\?\S+)?[^\.\s])?)?)@', '<a href="$1" target="_blank" rel="nofollow">$1</a>', $text);

          echo "<em>", "<span class = 'green'>", "Current Best Log is:", "</span>", "&nbsp;&nbsp;&nbsp;&nbsp;", $row2['message'], ",", " with ", "<span class = 'blue'>", $row2['aggr2'], "</span>", "<span class = ''>", " Net,", " by ", $row2['ip'], "</span>", "</em><br>";         
          /*while ($row = $sql->fetch(PDO::FETCH_ASSOC)){
          echo "<em>", "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;", $row['message'], ",", " by ", $row['ip'], ", with ", "</span>", "<b>", "<span class = 'green'>", $row['max_love'], "</span>", "</b>", "<span class = ''>", " Likes", "</span>", "</em><br>";
          }*/
          
          echo "<hr>";
          $sql3 = $db->query('select message, username, ip, max(diss-love) as aggr3 from posts group by (diss-love) desc limit 1');
          $row3 = $sql3->fetch(PDO::FETCH_ASSOC);
          
          $text = strip_tags($row2['message']);
$row2['message'] = preg_replace('@(https?://([-\w\.]+[-\w])+(:\d+)?(/([\w/_\.#-]*(\?\S+)?[^\.\s])?)?)@', '<a href="$1" target="_blank" rel="nofollow">$1</a>', $text);

          echo "<em>", "<span class = 'red'>", "Current Worst Log is:", "</span>", " ", $row3['message'], ",", " with ", "<span class = 'blue'>", "-", $row3['aggr3'], "</span>", "<span class = ''>", " Net,", " by ", $row3['ip'], "</span>", "</em><br>";         
          /*while ($row = $sql->fetch(PDO::FETCH_ASSOC)){
          echo "<em>", "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;", $row['message'], ",", " by ", $row['ip'], ", with ", "</span>", "<b>", "<span class = 'red'>", $row['max_diss'], "</span>", "</b>", "<span class = ''>", " Disses", "</span>", "</em><br>";
          }*/
          
          echo "<hr>";
          echo "<center><a href='rankings.php'><em>View full rankings</em></a></center><hr>";
          echo "<form name = 'search' action = 'search-notif.php' method = 'get'>
          <input type ='hidden' name = 'page' value = '1'>
          <label><em>Search entries by ID, Log, IP or Date; or leave blank to search all entries:</em></label><br>
          <input type = 'text' name = 'term'><br>
          <span class = 'button'><input type = 'submit' name = 'search' value = 'Search'></span>
          
          <hr>";
          
          echo "<a href='post.php'>Log</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='index.php'>Home</a>";
          ?>
          

      </body>
</html>