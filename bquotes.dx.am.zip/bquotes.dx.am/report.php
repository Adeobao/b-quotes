<html>
<head>
<title>Report Post: BQuotes - Anonymous Blogs & Quotes</title>
<meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=4.0, user-scalable=yes' />
    <link rel='stylesheet' type='text/css' href='style.css'>

<link rel="stylesheet"
          href="https://fonts.googleapis.com/css?family=Montserrat">
    <style>
      body {
        font-family: 'Montserrat';
        font-size: 24px;
      }
    </style>

</head>
<!--<body class = 'default'>-->

<script type = 'text/javascript'>
          var maxLength=140;
          function charLimit(el) {
              if (el.value.length > maxLength) return false;	
              return true;
          }
          function characterCount(el) {
              var charCount = document.getElementById('charCount');
              if (el.value.length > maxLength) el.value = el.value.substring(0,maxLength);
              if (charCount) charCount.innerHTML = maxLength - el.value.length;
              return true;
          }
      </script>
      <div data-role='main' class='ui-content'>

<?php
$db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
$sql = $db->query('select id from posts order by rand() limit 1');
$row = $sql->fetch(PDO::FETCH_ASSOC);
echo "<a href = 'random.php?page=".$row['id']."'>Randomize</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href = 'index.php'>Home</a>";
echo "<hr>";
$id = $_GET['page'];
$ip = $_GET['ip'];
$sql0 = $db->prepare("select message from posts where id = :id");
$sql0->bindParam(':id', $id);
$sql0->execute();
$sql0->setFetchMode(PDO::FETCH_ASSOC);
$row0 = $sql0->fetch();
echo "<form name = 'report' action = 'report-notif.php' method = 'post'>
     <label>Review Inappropriate update, fill your comments and the captcha and then tap 'Report'</label><br>
     <hr>
     <label>Update to report:</label><br>
     <textarea readonly rows='6' cols='18' style='border-radius:5px; padding: 4px 14px;'>".$row0['message']."</textarea><br>     
     <label>ID:</label><br>
     <input type = 'number' name = 'id' value = ".$id." readonly  style='border-radius:5px; padding: 4px 14px;'><br>
     <label>IP:</label><br>
     <input type = 'text' name = 'ip' value = ".$ip." readonly  style='border-radius:5px; padding: 4px 14px;'><br>
     <label>Comments:</label><br>
     <textarea name='comments' rows='6' cols='18' onKeyPress='return charLimit(this)' onKeyUp='return characterCount(this)' name='message' wrap='physical'  style='border-radius:5px; padding: 4px 14px;'></textarea><br>
     <p><strong><span id='charCount'>140</span></strong> characters remaining.</p>
     <label>Enter Image Text:</label><img src='captcha.php' /><br />
     <input name='captcha' type='number'  style='border-radius:5px; padding: 4px 14px;'><br>
     <input type = 'submit' name = 'submit' value = 'Report'  style='border-radius:5px; padding: 4px 14px;'><br>
     </form>";
echo "<hr>";
echo "<a href = 'random.php?page=".$row['id']."'>Randomize</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href = 'index.php'>Home<a>";
?>
<br>
<center><footer>
       <?php include("counter.php");?>     

     </footer></center>

</body>
</html>