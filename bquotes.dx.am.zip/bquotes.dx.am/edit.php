<html>
<head>
<title>Edit: BQuotes</title>
<meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no' />
<link type = 'text/css' rel = 'stylesheet' href = 'style.css'>
</head>

<?php
$db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
$sql = $db->query('select id from posts order by rand() limit 1');
$row = $sql->fetch(PDO::FETCH_ASSOC);
echo "<a href = 'random.php?page=".$row['id']."'>Randomize</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href = 'index.php'>Home</a>";
echo "<hr>";
$id = $_GET['page'];
$username = $_GET['username'];
$sql0 = $db->prepare("select message from posts where id = :id");
$sql0->bindParam(':id', $id);
$sql0->execute();
$sql0->setFetchMode(PDO::FETCH_ASSOC);
$row0 = $sql0->fetch();
echo "<form name = 'edit' action = 'edit-notif.php' method = 'post'>
     <label><em>Edit your message, fill in your password, fill the captcha and click 'Edit'</em></label><br>
     <label>------</label><br>
     <label><em>Message to edit:</em></label><br>
     <textarea name='message' rows='7' cols='20'>".$row0['message']."</textarea><br>
     <label><em>Message ID:</em></label><br>
     <input type = 'text' name = 'id' value = ".$id." readonly><br>
     <label><em>Username:</em></label><br>
     <input type = 'text' name = 'username' value = '$username' readonly><br>
     <label><em>Password:</em></label><br>
     <input type = 'password' name = 'password'><br>
     <em>Enter Image Text:</em><img src='captcha.php' /><br />
     <input name='captcha' type='text' /><br>
     <input type = 'submit' name = 'submit' value = 'Edit'><br>
     </form>";
echo "<hr>";
echo "<a href = 'random.php?page=".$row['id']."'>Randomize</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href = 'index.php'>Home<a>";
?>
</html>