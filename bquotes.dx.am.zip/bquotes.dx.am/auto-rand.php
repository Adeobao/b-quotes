<html>
    <head>
    <title>Auto-Random: BQuotes</title>
    <meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no' />
    <link rel='stylesheet' type='text/css' href='style.css'>
    <meta name='description' content=''>
    <meta name='keywords' content='Blogs, Quotes, Music'>
    <meta http-equiv = 'refresh' content = '6'>
    </head>
    <body class = 'default'>

<a href='post.php'>Log</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='index.php'>Home</a><br>
<span class = 'small_red'>please wait a moment; page will auto-refresh.</span>
<hr>


            <?php
            error_reporting(0);
            //error_reporting(E_ALL);
              session_start();                     
              $db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
              
              $sql = $db->query('SELECT * FROM posts ORDER BY RAND() LIMIT 1');
              $row = $sql->fetch(PDO::FETCH_ASSOC);
                  
              //if ($row['sort'] == "text"){
              //echo "<em>", "Log:<br>", "</em>";
              echo "Log: ", "<em>", ($row['message']), "</em>", "<br>";
              echo "By: ", "&nbsp;&nbsp;", "<span class = ''>", "<em>", $row['author'], "</em>", "</span>", "<br>";
              echo "On: ", "&nbsp;&nbsp;", "<em>", ($row['date']), "</em>", "<br>";
              /*}
              
                               else {echo "<i>Nothing to Show Here!</i>";}*/
                               
              
          ?>
          
      </div>
                   
      <?php
          define ('HOSTNAME', 'fdb20.awardspace.net');
          define ('USERNAME', '2795841_adeoba');
          define ('PASSWORD', 'Makanjuola2');
          define ('DATABASE_NAME', '2795841_adeoba');

          $db = mysql_connect(HOSTNAME, USERNAME, PASSWORD) or die ('I cannot connect to MySQL.');

          mysql_select_db(DATABASE_NAME);

          $query = "SELECT COUNT(id) FROM posts";

          $result = mysql_query($query);

          while ($row = mysql_fetch_array($result)) {
           echo "<br><em>", ($row['COUNT(id)']), " Entries in Database</em>", "<br>";
          }

          mysql_free_result($result);
          mysql_close();
          
          $db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
              

          //echo "<hr>";
          
          /*$db = new PDO('mysql:host=fdb13.awardspace.net;dbname=2107121_defa;charset=utf8', '2107121_defa', 'Makanjuola2');
          $sql = $db->query('select message, ip, max(love) as max_love from posts group by love desc limit 0,10');
          $row = $sql->fetch(PDO::FETCH_ASSOC);
          echo "<em>", "<span class = ''>", "Current Best Log is:", " ", "&nbsp;&nbsp;&nbsp;", $row['message'], ",", " by ", $row['ip'], ", with ", "</span>", "<b>", "<span class = 'green'>", $row['max_love'], "</span>", "</b>", "<span class = ''>", " Likes", "</span>", "</em><br>"; */      
          /*while ($row = $sql->fetch(PDO::FETCH_ASSOC)){
          echo "<em>", "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;", $row['message'], ",", " by ", $row['ip'], ", with ", "</span>", "<b>", "<span class = 'green'>", $row['max_love'], "</span>", "</b>", "<span class = ''>", " Likes", "</span>", "</em><br>";
          }*/
          
          /*$sql = $db->query('select message, ip, max(diss) as max_diss from posts group by diss desc limit 0,10');
          $row = $sql->fetch(PDO::FETCH_ASSOC);
          echo "<em>", "<span class = ''>", "Current Worst Log is:", " ", $row['message'], ",", " by ", $row['ip'], ", with ", "</span>", "<b>", "<span class = 'red'>", $row['max_diss'], "</span>", "</b>", "<span class = ''>", " Disses", "</span>", "</em><br>"; */      
          /*while ($row = $sql->fetch(PDO::FETCH_ASSOC)){
          echo "<em>", "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;", $row['message'], ",", " by ", $row['ip'], ", with ", "</span>", "<b>", "<span class = 'red'>", $row['max_diss'], "</span>", "</b>", "<span class = ''>", " Disses", "</span>", "</em><br>";
          }*/
          
          echo "<hr>";
        ?>
      <span class = 'small_red'>please wait a moment; page will auto-refresh.</span><br>    
      <a href="post.php">Log</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='index.php'>Home</a>
      

                   
      </body>
</html>