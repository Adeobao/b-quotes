<html>
<head>
<title>Sponsor Post: BQuotes - Anonymous Blogs & Quotes</title>
<meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=4.0, user-scalable=yes' />
<link type = 'text/css' rel = 'stylesheet' href = 'style.css'>

<link rel="stylesheet"
          href="https://fonts.googleapis.com/css?family=Montserrat">
    <style>
      body {
        font-family: 'Montserrat';
        font-size: 24px;
      }
    </style>

</head>
<!--<body class = 'default'>-->

<script type = 'text/javascript'>
          var maxLength=140;
          function charLimit(el) {
              if (el.value.length > maxLength) return false;	
              return true;
          }
          function characterCount(el) {
              var charCount = document.getElementById('charCount');
              if (el.value.length > maxLength) el.value = el.value.substring(0,maxLength);
              if (charCount) charCount.innerHTML = maxLength - el.value.length;
              return true;
          }
      </script>
      <div data-role='main' class='ui-content'>

<?php
if(stristr($_SERVER['HTTP_REFERER'], "https://flutterwave.com/pay/nwr4audsd59d")) {

$db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');
$sql = $db->query('select id from posts order by rand() limit 1');
$row = $sql->fetch(PDO::FETCH_ASSOC);
echo "<a href = 'random.php?page=".$row['id']."'>Randomize</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href = 'index.php'>Home</a>";
echo "<hr>";
$id = $_GET['page'];
$username = $_GET['username'];
$sql0 = $db->prepare("select message from posts where id = :id");
$sql0->bindParam(':id', $id);
$sql0->execute();
$sql0->setFetchMode(PDO::FETCH_ASSOC);
$row0 = $sql0->fetch();


echo "<form name = 'post-spons' action = 'post-spons-notif.php' method = 'post'>
     <!--<label>Pay 1,200 Naira (1 month) into GTBank Account 0126272614 (Adeoba Oguntonade), and send the payment screenshot via WhatsApp to 0803-725-5066. I will get back to you with a userid & password to use for this page; then fill in the details and click 'Sponsor Update'. Your posts will appear more often among the total database selection.</label><br>-->
     <!--<hr>-->
     <label>Update to Sponsor:</label><br>
     <label><em>Use keypad emojis for emojis<br>
     Use http://google.com for google.com</em></label><br>
     <textarea id =  rows='6' cols='18' onKeyPress='return charLimit(this)' onKeyUp='return characterCount(this)' name='message' wrap='physical' style='border-radius:5px; padding: 4px 14px;'>".$row0['message']."</textarea><br>
     <p><strong><span id='charCount'>140</span></strong> characters remaining.</p>
     <label>Weight:<label><br>
     <input readonly type = 'number' id = 'myInput' name = 'visibility' on-keydown='' style='border-radius:5px; padding: 4px 14px;'><br>
     <!--<label>UserId:</label><br>
     <input type = 'text' name = 'userid' style='border-radius:5px; padding: 4px 14px;'><br>
     <label>Password:</label><br>
     <input type = 'password' name = 'password' style='border-radius:5px; padding: 4px 14px;'>--><br>
     Enter Image Text:<img src='captcha.php' /><br />
     <input name='captcha' type='number' style='border-radius:5px; padding: 4px 14px;'><br>
     <input type = 'submit' name = 'submit' value = 'Sponsor Update' style='border-radius:5px; padding: 4px 14px;'><br>
     </form>";
			
$stmt = $db->query("select SUM(weight) AS totweight from posts");
$stmt->execute();
$sum = $stmt->fetch();
//echo $sum['totweight'];
/*if ($_POST['visibility'] > 45){
exit ("Your Visibility level should be between 1 and 45");
}
else
{
$visibility = $_POST['visibility'];
}
$real_vi = ($visibility/$sum['totweight'])*100;*/

//dynamically make visibility 35%
$vi_dyn = (5*$sum['totweight'])/100;

echo "<hr>";
echo "<a href = 'random.php?page=".$row['id']."'>Randomize</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href = 'index.php'>Home<a>";

} 
else {exit ('You are not authorised to view this page'); }

?>
<script>
var dyn = <?php echo $vi_dyn ?>;
var myInput = document.getElementById('myInput');
myInput.value = dyn;
</script>

<br>
<center><footer>
       <?php include("counter.php");?>     

     </footer></center>

</body>
</html>