<html>
<head>
<title>Home: BQuotes - Anonymous Blogs & Quotes</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=4.0, user-scalable=yes" />
<link rel="stylesheet" type="text/css" href="style.css">
<meta name="description" content="">
<meta name="keywords" content="Blogs, Quotes, Music">

<link rel="stylesheet"
          href="https://fonts.googleapis.com/css?family=Montserrat">
    <style>
      body {
        font-family: 'Montserrat';
        font-size: 24px;
      }
    </style>
</head>
<body>

<!--<span class = 'default'>-->

          
          
          
          
          

<?php
error_reporting(0);
ob_start();
$db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8', '2795841_adeoba', 'Makanjuola2');

//echo "<em><b>Disclaimer:</b> User solely responsible for posts!</em>", "<br>";
//echo "<em>You can also access this site by typing <b>bquotes.me</b> in your browser</em><br>";
        		
              //$sql = $db->query('SELECT id FROM posts ORDER BY id DESC LIMIT 1');
              //$row = $sql->fetch(PDO::FETCH_ASSOC);
              
              $sql2 = $db->query('SELECT id FROM posts ORDER BY RAND() LIMIT 1');
              $row2 = $sql2->fetch(PDO::FETCH_ASSOC);
//echo "<a href='random.php?page=".$row2['id']."'>Randomize</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='browse.php?page=".$row['id']."'>Browse</a>";
echo "<a href = 'post.php'>Post</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href='random.php?page=".$row2['id']."'>Randomize</a>";
//<a href='browse.php?page=".$row['id']."'>Browse</a><hr/>";
echo "<br><h2><b>BQuotes</b>: Your Blogs & Quotes</h2>";
echo "<br><a href = 'https://flutterwave.com/pay/nwr4audsd59d'>Place An Ad</a> <br><br><a href=privacy.php>Privacy Policy</a>";
?>     
</span>
<br>
<center><footer>
       <?php include("counter.php");?>     

     </footer>
     <?php echo "Copyright &copy; 2011 - "; echo date('Y'); echo " of Adeoba Akinyemi Oguntonade Enterprises. All rights reserved.<br><h6><em>Disclaimers: User solely responsible for his content. App & All content is provided 'as is', without any guarantees, or representations as to its suitability for any purpose.</em></h6>"; ?>
     </center>
    </body>
    </html>