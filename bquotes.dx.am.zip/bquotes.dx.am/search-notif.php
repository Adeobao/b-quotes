<html>
<head>
<meta "content-Type: text/html; charset=utf-8">
<meta name = 'viewport' content = 'width = device-width, intial-scale = 1.0, maximum-scale = 4.0, user-scalable = yes'>
<link rel = 'stylesheet' href = 'style.css' type = 'text/css'>
<title>Search Notification: BQuotes - Anonymous Blogs & Quotes</title>

<link rel="stylesheet"
          href="https://fonts.googleapis.com/css?family=Montserrat">
    <style>
      body {
        font-family: 'Montserrat';
        font-size: 24px;
      }
    </style>

</head>
<!--<body class = 'default'>-->
<?php
//error_reporting(0);



$db = new PDO('mysql:host=fdb20.awardspace.net;dbname=2795841_adeoba;charset=utf8mb4', '2795841_adeoba', 'Makanjuola2');
$sql99 = $db->query('select id from posts order by rand() limit 1');
$row99 = $sql99->fetch(PDO::FETCH_ASSOC);
echo "<a href = 'random.php?page=".$row99['id']."'>Randomize</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href = 'index.php'>Home</a><hr>";
$term = '%'.($_GET['term']).'%';
$termx = trim($term, '%');

$q = $db->prepare('
        SELECT
            *
        FROM
            posts where convert(message using latin1) like (:term) or id like (:term) or ip like (:term) or date like (:term)
    ');
    //posts where match (message, username) against (:term IN BOOLEAN MODE) or date like (:term)
    $q->bindParam(':term', $term);
    $q->execute();    
    $total = $q->rowCount();
    
    // How many items to list per page
    $limit = 10;

    // How many pages will there be
    $pages = ceil($total / $limit);

    // What page are we currently on?
    $page = min($pages, filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT, array(
        'options' => array(
            'default'   => 1,
            'min_range' => 1,
        ),
    )));

//$page = 1;

  // Calculate the offset for the query
    $offset = ($page - 1)  * $limit;
    
    // Some information to display to the user
    $start = $offset + 1;
    $end = min(($offset + $limit), $total);
  
  echo $total, " Search results for '$termx':<hr>";
    // The "back" links
    $prevlink = ($page > 1) ? '<a href="search-notif.php?page=1&term='.$termx.'&search=Search" title="First page">First&nbsp;&nbsp;&nbsp;</a> <a href="?page=' . ($page - 1) . '&term='.$termx.'&search=Search" title="Previous page">Previous</a>' : '<span class="disabled">First&nbsp;&nbsp;&nbsp;</span> <span class="disabled">Previous</span>';

    // The "forward" links
    $nextlink = ($page < $pages) ? '<a href="search-notif.php?page=' . ($page + 1) . '&term='.$termx.'&search=Search" title="Next page">Next&nbsp;&nbsp;&nbsp;</a> <a href="?page=' . $pages . '&term='.$termx.'&search=Search" title="Last page">Last</a>' : '<span class="disabled">Next&nbsp;&nbsp;&nbsp;</span> <span class="disabled">Last</span>';

    // Display the paging information
    echo '<div id="paging"><p>', $prevlink, ' Page ', $page, ' of ', $pages, ' pages, displaying ', $start, '-', $end, ' of ', $total, ' results ', $nextlink, ' </p></div>';

    
//$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stmt = $db->prepare('select * from posts where convert(message using latin1) like (:term) or id like (:term) or ip like (:term) or date like (:term) order by id desc limit :limit offset :offset');

// Bind the query params
    $stmt->bindParam(':term', $term);
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();

    // Do we have any results?
    if ($stmt->rowCount() > 0) {
        // Define how we want to fetch the results
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $iterator = new IteratorIterator($stmt);


//echo "Browser shows: $html<br>";

echo "<ol>";

foreach($iterator as $row){
//show urls as links
$text = strip_tags($row['message']);
$row['message'] = preg_replace('@(https?://([-\w\.]+[-\w])+(:\d+)?(/([\w/_\.#-]*(\?\S+)?[^\.\s])?)?)@', '<a href="$1" target="_blank" rel="nofollow" style="background-color: wheat; color: blue">$1</a>', $text);
//echo $row['message'];

echo "<li>", $row['message'], "<br>", "ID: ", "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;", $row['id'], "<br>", "IP: ", "&nbsp;&nbsp;&nbsp;&nbsp;", $row['ip'], "<br>", "Date: ", $row['date'], "</li>", "<hr>";
}
echo "</ol>";
} else {
        echo '<p>No results could be displayed.</p>';
        }
 
 
    // The "back" links
    $prevlink = ($page > 1) ? '<a href="search-notif.php?page=1&term='.$termx.'&search=Search" title="First page">First&nbsp;&nbsp;&nbsp;</a> <a href="?page=' . ($page - 1) . '&term='.$termx.'&search=Search" title="Previous page">Previous</a>' : '<span class="disabled">First&nbsp;&nbsp;&nbsp;</span> <span class="disabled">Previous</span>';

    // The "forward" links
    $nextlink = ($page < $pages) ? '<a href="search-notif.php?page=' . ($page + 1) . '&term='.$termx.'&search=Search" title="Next page">Next&nbsp;&nbsp;&nbsp;</a> <a href="?page=' . $pages . '&term='.$termx.'&search=Search" title="Last page">Last</a>' : '<span class="disabled">Next&nbsp;&nbsp;&nbsp;</span> <span class="disabled">Last</span>';

    // Display the paging information
    echo '<div id="paging"><p>', $prevlink, ' Page ', $page, ' of ', $pages, ' pages, displaying ', $start, '-', $end, ' of ', $total, ' results ', $nextlink, ' </p></div>';
echo '<hr>';
echo "<a href = 'random.php?page=".$row99['id']."'>Randomize</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href = 'index.php'>Home</a>";
?>
<br>
<center><footer>
       <?php include("counter.php");?>     

     </footer></center>
</body>
</html>